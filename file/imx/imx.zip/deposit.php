<?php
include 'koneksi.php';
session_start();

if (!isset($_SESSION['login'])){
    header("location:login.php");
    exit;
}
$username = $_SESSION['username'];

	$cek_user = mysqli_query($con,"SELECT req_depo FROM deposit WHERE username = '$username'");
	$cek_depo = mysqli_num_rows($cek_user);

	if ($cek_depo > 0) {
		echo "<script>
		alert('Permintaan deposit anda sudah di ajukan sebelumnya, silahkan melakukan pembayaran atau tunggu deposit tersebut kami proses');
		window.location = 'billing.php';
		</script>";

}

if(isset($_POST['submit'])){
$deposit     = $_POST["depo"];
}

?>







<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>im3</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<style type="text/css">
    #wrapshopcart{width:310px;margin:auto;padding:50px;
     padding-bottom: 2px;margin-bottom: 20px;background:#fff;box-shadow:0 0 5px #c1c1c1;border-radius:5px;}
    #response{
        text-align: center;
    }
    #EE{
        width: 50%;
    }
    textarea { resize:none; }
    #count{
        text-align: right;
    }
</style>
</head>
<body>

  <br><div id="wrapshopcart">
    <center><h2>Deposit</h2><br>
    
    <center><h6><?php echo "Username: $username " ?></h6>
    
  <form action= "proses_depo.php" method= "post">
    <input type="number" name="depo" class= "form-control" placeholder="jumlah deposit" required><br>

    <input type="submit" name="submit" class="btn btn-success" value="kirim"><br>
    <br><a href="index.php">MENU</a><br>
    <br>
  </div>
</div>
</body>
</html>