<?php
include 'koneksi.php';
session_start();
if (!isset($_SESSION['login'])){
    header("location:login.php");
    exit;
}
$username = $_SESSION['username'];
$query = mysqli_query($con, "SELECT req_depo FROM deposit where username='$username'");
	$r  = mysqli_fetch_array($query);
if ($r > 0) {
$rdep = $r['req_depo'];
$req_dep = "Rp: " . number_format("$rdep", 0, ",", ".");
$info = "STATUS PENDING! Anda memiliki permintaan deposit sejumlah $req_dep yang belum terverifikasi. Silahkan transfer ke salah satu rekening kami dibawah ini lalu tekan tombol konfirmasi dan berikan bukti transaksi";
}else if ($r < 1) {
$info = "Deposit disetujui. Saldo berhasil ditambahkan, silahkan cek kembali saldo anda. Terimaksih "; 
}

?>


<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>im3</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<style type="text/css">
    #wrapshopcart{width:310px;margin:auto;padding:50px;
     padding-bottom: 2px;margin-bottom: 20px;background:#fff;box-shadow:0 0 5px #c1c1c1;border-radius:5px;}
    #response{
        text-align: center;
    }
    #EE{
        width: 50%;
    }
    textarea { resize:none; }
    #count{
        text-align: right;
    }
    <img src="qris.jpg" alt="xeileencell" style="width:20px;height:20px;">
</style>
</head>
<body>

  <br><div id="wrapshopcart">
<center>  
<form method="post" action="https://wa.me/6281646805770">
      
<h5> <?php echo "Hai $username" ?> </h5>
<h7> <?php echo $info ?> </h7><br>
<br>
<hr>    
<h7>Dana : 081646805770</h7><br><hr>
<h7>Ovo : 081646805770</h7><br><hr>
<h7>BRI : 440401025224534</h7><br><hr>
<h5>QRIS</h5><br>

 </p>
<img src="/image/qris.jpg" alt="xeileencell" style="width:200px;height:250px;"><br><br>
  
    <input type="submit" name="submit" class="btn btn-success" value="KONFIRMASI"><br>
    
    <br><a href="index.php">KEMBALI</a><br>

    <br>
  </div>
</div>
</body>
</html>


<?php

?>
