<?php
include 'koneksi.php';
session_start();

if (!isset($_SESSION['login'])){
    header("location:login.php");
    exit;
    }
$ussr = $_SESSION['nama'];
$usrnm = $_SESSION['username'];
$query = mysqli_query($con2,"SELECT * FROM $usrnm");

?>


<!DOCTYPE html>
<html>
<head>
<title>im3</title>
<style>
h1{
  font-family: sans-serif;
}
 
table {
  font-family: Arial, Helvetica, sans-serif;
  color: #666;
  text-shadow: 1px 1px 0px #fff;
  background: #eaebec;
  border: #ccc 1px solid;
}
 
table th {
  padding: 15px 35px;
  border-left:1px solid #e0e0e0;
  border-bottom: 1px solid #e0e0e0;
  background: #ededed;
}
 
table th:first-child{  
  border-left:none;  
}
 
table tr {
  text-align: center;
  padding-left: 20px;
}
 
table td:first-child {
  text-align: left;
  padding-left: 20px;
  border-left: 0;
}
 
table td {
  padding: 15px 35px;
  border-top: 1px solid #ffffff;
  border-bottom: 1px solid #e0e0e0;
  border-left: 1px solid #e0e0e0;
  background: #fafafa;
  background: -webkit-gradient(linear, left top, left bottom, from(#fbfbfb), to(#fafafa));
  background: -moz-linear-gradient(top, #fbfbfb, #fafafa);
}
 
table tr:last-child td {
  border-bottom: 0;
}
 
table tr:last-child td:first-child {
  -moz-border-radius-bottomleft: 3px;
  -webkit-border-bottom-left-radius: 3px;
  border-bottom-left-radius: 3px;
}
 
table tr:last-child td:last-child {
  -moz-border-radius-bottomright: 3px;
  -webkit-border-bottom-right-radius: 3px;
  border-bottom-right-radius: 3px;
}
 
table tr:hover td {
  background: #f2f2f2;
  background: -webkit-gradient(linear, left top, left bottom, from(#f2f2f2), to(#f0f0f0));
  background: -moz-linear-gradient(top, #f2f2f2, #f0f0f0);
}

</style>
</head>
<body>

    <br><center><h2>History transaksi</h2>
    <br><center><h2><?php echo "Username: $ussr"; ?></h2>
      
<form method="post" action=""><br>
<table>

<form action="" method="post">

            <th>No</th>
            <th>Date</th>
            <th>Nomor Hp</th>
            <th>Paket</th>
            <th>Harga</th>
            <th>Status</th>

         <?php if(mysqli_num_rows($query)>0){ ?>
        <?php
            $no = 1;
            while($data = mysqli_fetch_array($query)){
        ?>
        <tr>
            <td><?php echo $no ?></td>
            <td><?php echo $data["date"];?></td>
            <td><?php echo $data["nomor"];?></td>
            <td><?php echo $data["nama_paket"];?></td>
            <td><?php $ss = $data["harga"]; $s = "Rp: " . number_format("$ss", 0, ",", "."); echo $s; ?></td>
            <td><?php echo $data["status"];?></td>

        </tr>
        <?php $no++; } ?>
        <?php } ?>
    </table>

     
      
       
        
         
          
            <br><a href="index.php">KEMBALI</a>
    <br></br>
    
  </div>
</div>
</body>
</html>
