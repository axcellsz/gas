<?php
include 'koneksi.php';

if (isset($_POST['submit'])) {
	$nama = $_POST['nama'];
	$username = $_POST['username'];
	$password1 = $_POST['password1'];
	$password2 = $_POST['password2'];
    $nomor = $_POST['no_ovo'];

	$cek_user = mysqli_query($con,"SELECT * FROM user WHERE username = '$username'");
	$cek_login = mysqli_num_rows($cek_user);

	if ($cek_login > 0) {
		echo "<script>
		alert('username telah terdaptar');
		window.location = 'registrasi.php';
		</script>";
	}else {
		if ($password1 != $password2){
			echo "<script>
		alert('konfirmasi password tidak sesuai');
		window.location = 'registrasi.php';
		</script>";
	}else {
        $saldo = "0";
		$password = password_hash($password1,PASSWORD_DEFAULT);
		mysqli_query($con,"INSERT INTO user VALUES('$nama','$username','$password','$saldo','$nomor')");

define('HOST', 'localhost');
define('USER', 'root');
define('PASS', 'DeviAconk+x66');
define('DBNAME', 'xeileenc');

$db = new mysqli(HOST, USER, PASS, DBNAME);

// Bikin tabelnya 
$create_table =
'CREATE TABLE IF NOT EXISTS '.$username.'  
(
    no_trx INT NOT NULL AUTO_INCREMENT,
    date VARCHAR(50) NOT NULL,
    nomor CHAR(15) NOT NULL,
    nama_paket VARCHAR(100) NOT NULL,
    harga CHAR(10) NOT NULL,
    status VARCHAR(100) NOT NULL,
    PRIMARY KEY(no_trx)
)';

$create_tbl = $db->query($create_table);
if ($create_table) {
			    echo "<script>
		    alert('Registrasi berhasil, Silahkan login');
		    window.location = 'login.php';
			</script>";
}
$db->close();





	     }
    }
}
	

?>
<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>im3</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<style type="text/css">
    #wrapshopcart{width:310px;margin:auto;padding:50px;
     padding-bottom: 2px;margin-bottom: 20px;background:#fff;box-shadow:0 0 5px #c1c1c1;border-radius:5px;}
    #response{
        text-align: center;
    }
    #EE{
        width: 50%;
    }
    textarea { resize:none; }
    #count{
        text-align: right;
    }
</style>
</head>
<body>

  <br><div id="wrapshopcart">
    <center><h2>Registrasi</h2><br>
  <form action= "" method= "post">
    <input type="text" name="nama" class= "form-control" placeholder="Nama lengkap"><br>
    
    <input type="text" name="username" class= "form-control" placeholder="Nama pengguna"><br>
    
    <input type="password" name="password1" class= "form-control" placeholder="Password"><br>
    
    <input type="password" name="password2" class= "form-control" placeholder="Masukan lagi password "><br>
    
        <input type="number" name="no_ovo" class= "form-control" placeholder="Nomor OVO"><br>
    
    
    <input type="submit" name="submit" class="btn btn-success" value="DAFTAR"><br>
    
    <br><a href="login.php">Login</a>
    <br></br>
  </div>
</div>
</body>
</html>
