<?php
include 'koneksi.php';

$username = $_GET ['username'];

$hapus = mysqli_query($con, "delete FROM deposit where username='$username'");

if ($hapus) {
echo "<script>
      alert('Deposit ditolak ');
      window.location = '/admin/admin.php';
      </script>";
}else{
echo "<script>
      alert('Gagal tolak deposit');
      window.location = '/admin/admin.php';
      </script>";
}


?>