<?php
include 'koneksi.php';
session_start();

if (!isset($_SESSION['admin'])){
    header("location:/admin/login_admin.php");
    exit;
    }

$query = mysqli_query($con,"SELECT * FROM user");

?>


<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>im3</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<style type="text/css">
    #wrapshopcart{width:310px;margin:auto;padding:50px;
     padding-bottom: 2px;margin-bottom: 20px;background:#fff;box-shadow:0 0 5px #c1c1c1;border-radius:5px;}
    #response{
        text-align: center;
    }
    #EE{
        width: 50%;
    }
    textarea { resize:none; }
    #count{
        text-align: right;
    }
table {
  border-collapse: collapse;
  width: 95%;
  
}

th, td {
  padding: 0px;
  text-align: left;
  border-bottom: 2px solid #ddd;
}
#tr:hover {background-color: silver;}
</style>
</head>
<body>

    <br><center><h3>User Manager</h3>
      
<form method="post" action=""><br>
<h5>List seller</h5>
<hr>
<table>

            <th>No</th>
            <th>User</th>
            <th>Saldo</th>
            <th>Act</th>
        </tr>
         <?php if(mysqli_num_rows($query)>0){ ?>
        <?php
            $no = 1;
            while($data = mysqli_fetch_array($query)){
        ?>
        <tr>
            <td><?php echo $no ?></td>
            <td><?php echo $data["username"];?></td>
            <td><?php $ss = $data["saldo"]; $s = "Rp: " . number_format("$ss", 0, ",", "."); echo $s; ?></td>
            <td>
                <a href="/admin/delete_user.php?username=<?php echo $data ['username']; ?>">Delete</a>
                <a href="/admin/update_saldo.php?username=<?php echo $data ['username']; ?>">Update</a>
            </td>
        </tr>
        <?php $no++; } ?>
        <?php } ?>
    </table>
    <br>
    

<h5>Permintaan deposit</h5>
<hr>
<?php 
$query = mysqli_query($con,"SELECT * FROM deposit");
?>
<table>
            <th>No</th>
            <th>User</th>
            <th>Saldo</th>
            <th>Act</th>
        </tr>
         <?php if(mysqli_num_rows($query)>0){ ?>
        <?php
            $no = 1;
            while($data = mysqli_fetch_array($query)){
        ?>
        <tr>
            <td><?php echo $no ?></td>
            <td><?php echo $data["username"];?></td>
            <td><?php $ss = $data["req_depo"]; $s = "Rp: " . number_format("$ss", 0, ",", "."); echo $s; ?></td>
            <td>
                <a href="/admin/tolak_deposit.php?username=<?php echo $data ['username']; ?>">Tolak</a>
                <a href="/admin/konfirmasi_deposit.php?username=<?php echo $data ['username']; ?>">Konfirm</a>
            </td>
        </tr>
        <?php $no++; } ?>
        <?php } ?>
        
        </table>
        <br>
    


     
      
       
        
<a href= "/admin/histori_deposit.php">Histori deposit</a>
         
  <br>
  <br>

<a href="/admin/logout.php">Logout</a>
    <br></br>
    
  </div>
</div>
</body>
</html>
