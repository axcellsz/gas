<?php
$hostname = "localhost";
$user = "root";
$password_db = "DeviAconk+x66";
$db_name = "xeileenc";
$db_name2 = "xeileenc";

$con = mysqli_connect($hostname,$user,$password_db,$db_name) or die(mysqli_error($con));

$con2 = mysqli_connect($hostname,$user,$password_db,$db_name2) or die(mysqli_error($con));

?>
