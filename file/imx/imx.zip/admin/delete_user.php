<?php
include 'koneksi.php';

$username = $_GET ['username'];
echo $username;

$hapus = mysqli_query($con, "delete FROM user where username='$username'");

$hapus2 = mysqli_query($con2, "DROP TABLE $username");


if ($hapus) {
echo "<script>
      alert('berhasil dihapus');
      window.location = '/admin/admin.php';
      </script>";
}else{
echo "<script>
      alert('gagal menghapus');
      window.location = '/admin/admin.php';
      </script>";
}


?>



<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>im3</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<style type="text/css">
    #wrapshopcart{width:310px;margin:auto;padding:50px;
     padding-bottom: 2px;margin-bottom: 20px;background:#fff;box-shadow:0 0 5px #c1c1c1;border-radius:5px;}
    #response{
        text-align: center;
    }
    #EE{
        width: 50%;
    }
    textarea { resize:none; }
    #count{
        text-align: right;
    }
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  padding: 3px;
  text-align: left;
  border-bottom: 2px solid #ddd;
}
#tr:hover {background-color: silver;}
</style>
</head>
<body>

  <br><div id="wrapshopcart">
    <center><h5>Halaman Admin</h2>
      
<form method="post" action=""><br>
<table>


            <br><a href="/admin/logout.php">Logout</a>
    <br></br>
    
  </div>
</div>
</body>
</html>
