<?php
include 'koneksi.php';


$username = $_GET ['username'];

$query1 = mysqli_query($con, "SELECT saldo FROM user where username='$username'");
	$r1  = mysqli_fetch_array($query1);
$sisa_sld = $r1['saldo'];



$query2 = mysqli_query($con, "SELECT req_depo FROM deposit where username='$username'");
	$r2  = mysqli_fetch_array($query2);
$req_saldo = $r2['req_depo'];


$saldo = $req_saldo + $sisa_sld;

$rest = mysqli_query($con, "update user set saldo='$saldo' where username='$username'");

date_default_timezone_set('Asia/Jakarta');
$waktu = date('Y-m-d H:i:s');
$status = "SUKSES";

$hist="insert into histori_deposit (date,username,jumlah,status) values
		('$waktu','$username','$req_saldo','$status')";
$hasil=mysqli_query($con,$hist);


$condep = mysqli_query($con, "delete FROM deposit where username='$username'");

if ($condep) {
echo "<script>
      alert('Permintaan deposit dikonfirmasi');
      window.location = '/admin/admin.php';
      </script>";
}else{
echo "<script>
      alert('Permintaan deposit gagal dikonfirmasi');
      window.location = '/admin/admin.php';
      </script>";
}

?>