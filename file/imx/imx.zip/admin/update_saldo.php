<?php
include 'koneksi.php';


$usrnm = $_GET ['username'];

$query = mysqli_query($con, "SELECT saldo FROM user where username='$usrnm'");
	$r  = mysqli_fetch_array($query);
$saldo = $r['saldo'];
$sisa_saldo = "Saldo Rp: " . number_format("$saldo", 0, ",", ".");


if (isset($_POST['submit1'])){
$tambah = $_POST['saldo'];
$jumlah = $tambah + $saldo;


$rest = mysqli_query($con, "update user set saldo='$jumlah' where username='$usrnm'");
if ($rest) {
echo "<script>
      alert('saldo berhasil ditambahkan');
      window.location = '/admin/admin.php';
      </script>";
}else{
echo "<script>
      alert('saldo gagal ditambahkan');
      window.location = '/admin/admin.php';
      </script>";
   }

}

?>

<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>im3</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<style type="text/css">
    #wrapshopcart{width:310px;margin:auto;padding:50px;
     padding-bottom: 2px;margin-bottom: 20px;background:#fff;box-shadow:0 0 5px #c1c1c1;border-radius:5px;}
    #response{
        text-align: center;
    }
    #EE{
        width: 50%;
    }
    textarea { resize:none; }
    #count{
        text-align: right;
    }
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  padding: 3px;
  text-align: left;
  border-bottom: 2px solid #ddd;
}
#tr:hover {background-color: silver;}
</style>
</head>
<body>

  <br><div id="wrapshopcart">
    <center><h5>Update saldo</h5><hr>
    <center><h7> <?php echo "Username : $usrnm"; ?>  </h7>
   <center><h7> <?php echo "$sisa_saldo"; ?>  </h7>
      
<form method="post" action=""><br>
<table>
    <input type="number" name="saldo" class= "form-control" placeholder="Masukan jumlah saldo"><br>
    
    <input type="submit" name="submit1" class="btn btn-success" value="Tambah saldo"><br>
    
            <br><a href="/admin/admin.php">Kembali</a>
    <br></br>
    
  </div>
</div>
</body>
</html>
