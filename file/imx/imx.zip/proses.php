<?php

include 'koneksi.php';
session_start();
if (!isset($_SESSION['login'])){
    header("location:login.php");
    exit;
    }
$ussr = $_SESSION['nama'];
$usrnm = $_SESSION['username'];
$nom = $_POST['nomor'];
//ambil data saldo//
$query = mysqli_query($con, "SELECT saldo FROM user where username='$usrnm'");
	$r  = mysqli_fetch_array($query);
$saldo = $r['saldo'];

$query = mysqli_query($con, "SELECT nomor FROM user where username='$usrnm'");
	$nov  = mysqli_fetch_array($query);
$no_ovo = $nov['nomor'];

// kalkulasi saldo//
if (isset($_POST['submit1']))
{
  $package_name = "Internet 2.5Gb 30Hari";
  $harga = "2000";
  $package = "1";
  $hasil = $saldo - $harga;
}
else if (isset($_POST['submit2']))
     {
        $package_name = "Internet 7Gb 30Hari";
        $harga = "2000";
        $package = "2";
        $hasil = $saldo - $harga;
      }
else if (isset($_POST['submit3']))
     {
        $package_name = "Internet 10Gb 30Hari";
        $harga = "2000";
        $package = "3";
        $hasil = $saldo - $harga;
     }
else if (isset($_POST['submit4']))
     {
          $package_name = "Paket EDU 30Gb";
          $harga = "2000";
          $package = "4";
          $hasil = $saldo - $harga;
     }
else if(isset($_POST['submit5']))
     {
          $package_name = "Paket Telpon 30hari";
          $harga = "2000";
          $package = "5";
          $hasil = $saldo - $harga;
     }
//beli paket//
$resh = "Rp: " . number_format("$harga", 0, ",", ".");

if($saldo < $harga) {
  echo "<script>
      alert(' Transaksi Gagal !! Saldo tidak mencukupi, silahkan deposit terlebih dahulu');
      window.location = 'depo.php';
      </script>";
}
else if($saldo > $harga) {

     switch ($package){
case "1":
$data = '{
	"tokenid": "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIiLCJzY2xzIjoiNjQxIiwiY3JlYXRlZGRhdGUiOiIyMDIzLTExLTMwIDIwOjE3OjUxLjgzNSIsImNoYW5uZWwiOiJWMk1ZSU0zIiwidXNlcnR5cGUiOiJQUkVQQUlEIiwiYXBwdmVyc2lvbiI6IjgxLjE1LjAiLCJsYW5ndWFnZSI6IklEIiwicDJwIjoidHJ1ZSIsIm5ldHdvcmsiOiJXSUZJIiwiYXV0aHR5cGUiOjIsInVwZGF0ZWRkYXRlIjoiMjAyMy0xMS0zMCAyMDoxNzo1MS44MzUiLCJpYyI6bnVsbCwibXNpc2RuIjoiYWI1M2ZhYmM3OWI4MDU5MmE4MDFlNDhkMDciLCJvc3ZlcnNpb24iOiI3LjEuMiIsImV4cCI6MjI1NjUwMTUwMjcxLCJpYXQiOjE3MDEzNTAyNzEsIm9zbmFtZSI6IkFuZHJvaWQifQ.lv9MK5DGhry1FWKwdhEoIcYoxC7z1yQnC_yPCU99kJNdwlQTrEuipcL2jIbZPoJGqzxCgCyjJsLLqlbWTJLqQg",
	"keyword": "6d62191e6c69181b6f1e7969",
	"shortcode": "929",
	"offerid": "6d62191e6c69181b6f1e796974121b74677f78",
	"name": "paket",
	"packagename": "Freedom Internet 2.5GB / 30 Hari",
	"normalprice": "5000",
	"discountprice": 5000,
	"paymentchannel": {
		"payment": "ovo",
		"value": "'.$no_ovo.'"
	},
	"check": true,
	"giftnumber": "'.$nom.'"
}';
 break;

 case "2":
 $data = '{
	"tokenid": "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIiLCJzY2xzIjoiNjQxIiwiY3JlYXRlZGRhdGUiOiIyMDIzLTExLTMwIDIwOjE3OjUxLjgzNSIsImNoYW5uZWwiOiJWMk1ZSU0zIiwidXNlcnR5cGUiOiJQUkVQQUlEIiwiYXBwdmVyc2lvbiI6IjgxLjE1LjAiLCJsYW5ndWFnZSI6IklEIiwicDJwIjoidHJ1ZSIsIm5ldHdvcmsiOiJXSUZJIiwiYXV0aHR5cGUiOjIsInVwZGF0ZWRkYXRlIjoiMjAyMy0xMS0zMCAyMDoxNzo1MS44MzUiLCJpYyI6bnVsbCwibXNpc2RuIjoiYWI1M2ZhYmM3OWI4MDU5MmE4MDFlNDhkMDciLCJvc3ZlcnNpb24iOiI3LjEuMiIsImV4cCI6MjI1NjUwMTUwMjcxLCJpYXQiOjE3MDEzNTAyNzEsIm9zbmFtZSI6IkFuZHJvaWQifQ.lv9MK5DGhry1FWKwdhEoIcYoxC7z1yQnC_yPCU99kJNdwlQTrEuipcL2jIbZPoJGqzxCgCyjJsLLqlbWTJLqQg",
	"keyword": "6d621c6c69181b6f1a1e7969",
	"shortcode": "929",
	"offerid": "6d621c6c69181b6f1a1e796974121b74677f78",
	"name": "paket",
	"packagename": "Freedom Internet 7GB Rp15rb",
	"normalprice": "15000",
	"discountprice": 15000,
	"paymentchannel": {
		"payment": "ovo",
		"value": "'.$no_ovo.'"
	},
	"check": true,
	"giftnumber": "'.$nom.'"
}';
 break;

 case "3":
 $data = '{
	"tokenid": "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIiLCJzY2xzIjoiNjQxIiwiY3JlYXRlZGRhdGUiOiIyMDIzLTExLTMwIDIwOjE3OjUxLjgzNSIsImNoYW5uZWwiOiJWMk1ZSU0zIiwidXNlcnR5cGUiOiJQUkVQQUlEIiwiYXBwdmVyc2lvbiI6IjgxLjE1LjAiLCJsYW5ndWFnZSI6IklEIiwicDJwIjoidHJ1ZSIsIm5ldHdvcmsiOiJXSUZJIiwiYXV0aHR5cGUiOjIsInVwZGF0ZWRkYXRlIjoiMjAyMy0xMS0zMCAyMDoxNzo1MS44MzUiLCJpYyI6bnVsbCwibXNpc2RuIjoiYWI1M2ZhYmM3OWI4MDU5MmE4MDFlNDhkMDciLCJvc3ZlcnNpb24iOiI3LjEuMiIsImV4cCI6MjI1NjUwMTUwMjcxLCJpYXQiOjE3MDEzNTAyNzEsIm9zbmFtZSI6IkFuZHJvaWQifQ.lv9MK5DGhry1FWKwdhEoIcYoxC7z1yQnC_yPCU99kJNdwlQTrEuipcL2jIbZPoJGqzxCgCyjJsLLqlbWTJLqQg",
	"keyword": "6d621a1b6c69181b6f191b7969",
	"shortcode": "929",
	"offerid": "6d621a1b6c69181b6f191b796974121b74677f78",
	"name": "paket",
	"packagename": "Freedom Internet 10GB / 30 Hari",
	"normalprice": "20000",
	"discountprice": 20000,
	"paymentchannel": {
		"payment": "ovo",
		"value": "'.$no_ovo.'"
	},
	"check": true,
	"giftnumber": "'.$nom.'"
}';
 break;

 case "4":
 $data = '{
	"tokenid": "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIiLCJzY2xzIjoiNjQxIiwiY3JlYXRlZGRhdGUiOiIyMDIzLTExLTMwIDIwOjE3OjUxLjgzNSIsImNoYW5uZWwiOiJWMk1ZSU0zIiwidXNlcnR5cGUiOiJQUkVQQUlEIiwiYXBwdmVyc2lvbiI6IjgxLjE1LjAiLCJsYW5ndWFnZSI6IklEIiwicDJwIjoidHJ1ZSIsIm5ldHdvcmsiOiJXSUZJIiwiYXV0aHR5cGUiOjIsInVwZGF0ZWRkYXRlIjoiMjAyMy0xMS0zMCAyMDoxNzo1MS44MzUiLCJpYyI6bnVsbCwibXNpc2RuIjoiYWI1M2ZhYmM3OWI4MDU5MmE4MDFlNDhkMDciLCJvc3ZlcnNpb24iOiI3LjEuMiIsImV4cCI6MjI1NjUwMTUwMjcxLCJpYXQiOjE3MDEzNTAyNzEsIm9zbmFtZSI6IkFuZHJvaWQifQ.lv9MK5DGhry1FWKwdhEoIcYoxC7z1yQnC_yPCU99kJNdwlQTrEuipcL2jIbZPoJGqzxCgCyjJsLLqlbWTJLqQg",
	"keyword": "6e6f7e6a7b7b78181b6c69",
	"shortcode": "363",
	"offerid": "6e6f7e6a7b7b78181b6c69741a1b1b74677f78",
	"name": "paket",
	"packagename": "Freedom Apps EDU 30GB/30 Hari",
	"normalprice": "24800",
	"discountprice": 24800,
	"paymentchannel": {
		"payment": "ovo",
		"value": "'.$no_ovo.'"
	},
	"check": true,
	"giftnumber": "'.$nom.'"
}';

break;

case "5":
 $data = '{
	"tokenid": "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIiLCJzY2xzIjoiNjQxIiwiY3JlYXRlZGRhdGUiOiIyMDIzLTExLTMwIDIwOjE3OjUxLjgzNSIsImNoYW5uZWwiOiJWMk1ZSU0zIiwidXNlcnR5cGUiOiJQUkVQQUlEIiwiYXBwdmVyc2lvbiI6IjgxLjE1LjAiLCJsYW5ndWFnZSI6IklEIiwicDJwIjoidHJ1ZSIsIm5ldHdvcmsiOiJXSUZJIiwiYXV0aHR5cGUiOjIsInVwZGF0ZWRkYXRlIjoiMjAyMy0xMS0zMCAyMDoxNzo1MS44MzUiLCJpYyI6bnVsbCwibXNpc2RuIjoiYWI1M2ZhYmM3OWI4MDU5MmE4MDFlNDhkMDciLCJvc3ZlcnNpb24iOiI3LjEuMiIsImV4cCI6MjI1NjUwMTUwMjcxLCJpYXQiOjE3MDEzNTAyNzEsIm9zbmFtZSI6IkFuZHJvaWQifQ.lv9MK5DGhry1FWKwdhEoIcYoxC7z1yQnC_yPCU99kJNdwlQTrEuipcL2jIbZPoJGqzxCgCyjJsLLqlbWTJLqQg",
	"keyword": "7d1b1b1a1b1b656a191b1b",
	"offerid": "7d1b1b1a1b1b656a191b1b74121b74677f78",
	"name": "paket",
	"packagename": "Nelpon Sepuasnya ke Sesama Indosat dan Tri / 30 Hari",
	"normalprice": "5000",
	"discountprice": 5000,
	"paymentchannel": {
		"payment": "ovo",
		"value": "'.$no_ovo.'"
	},
	"check": true,
	"giftnumber": "'.$nom.'"
}';

break;
}

$url = 'https://im3ku.netlify.app/api/users/buy_package';
$ch = curl_init($url);

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Content-Type: application/json',
    'Content-Length: ' . strlen($data)
));

$response = curl_exec($ch);
if(curl_errno($ch)) 
{
    echo 'Error: ' . curl_error($ch);
} 

curl_close($ch);
//olah respone dan saldo//
$dots = json_decode($response, true);
$jos = $dots["status"];
switch ($jos){
case "1":
 $stts = "GAGAL";
 break;
case "0":
 $stts = "SUKSES";
 break;
 }
//simpan history transaksi//
date_default_timezone_set('Asia/Jakarta');
$waktu = date('Y-m-d H:i:s');
$date = "$waktu";
$nomor = $nom;
$nama_paket = $package_name;
$status = "$stts";
$s = "Rp: " . number_format("$harga", 0, ",", ".");

  $sql="insert into $usrnm (date,nomor,nama_paket,harga,status) values
		('$date','$nomor','$nama_paket','$harga','$status')";
  $exec = mysqli_query($con2,$sql);

///status transaksi///
if ($jos == "0")
{
mysqli_query($con, "update user set saldo='$hasil' where username='$usrnm'");
echo "<script>
      alert('Pesanan $package_name untuk no. $nom harga $s sudah dibuatkan ! Silahkan konfirmasi pembayaran melalui aplikasi ovo di nomor $no_ovo  ');
      window.location = 'index.php';
      </script>";
}
else if($jos == "1")
{
echo "<script>
      alert(' Transaksi Gagal !!  nomor salah atau tidak terdaptar $response ');
      window.location = 'index.php';
      </script>";
   }
}


?>