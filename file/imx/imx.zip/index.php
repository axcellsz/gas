<?php
include 'koneksi.php';
session_start();


if (!isset($_SESSION['login'])){
    header("location:login.php");
    exit;
}
$ussr = $_SESSION['nama'];
$usrnm = $_SESSION['username'];

$query = mysqli_query($con, "SELECT saldo FROM user where username= '$usrnm'");
	$r  = mysqli_fetch_array($query);
$saldo = $r['saldo'];
$sisa_saldo = "Saldo Rp: " . number_format("$saldo", 0, ",", ".");


?>


<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>im3</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<style type="text/css">
    #wrapshopcart{width:310px;margin:auto;padding:50px;
     padding-bottom: 2px;margin-bottom: 20px;background:#fff;box-shadow:0 0 5px #c1c1c1;border-radius:5px;}
    #response{
        text-align: center;
       
    }
    #EE{
        width: 50%;
    }
    textarea { resize:none; }
    #count{
        text-align: right;
    }
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    
  
    
</style>
</head>
<body>

    <br><div id="wrapshopcart">
    <h5><?php echo "Username:  $ussr"; ?></h5><hr>
    <h7><?php echo $sisa_saldo ?>
<h7><br><a href="deposit.php">Tambah saldo</a><br><br>

</form>

<form method="post" action="proses.php">


<table>

  <input type="number" name="nomor" class= "form-control" placeholder="Nomor im3" required><br>
  
  <input type="submit" class="btn btn-success" name="submit1" value="Paket Inet 2.5GB 30Hari" style="width: 100%;height:40px;"/>
  <center><font face="Courier New" size="2" color="#f0f0g88f">Harga Rp. 7rb</font><br>
  
  <br><input type="submit" class="btn btn-success" name="submit2" value="Paket Inet 7GB 30Hari" style="width: 100%;height:40px;"/>
  <center><font face="Courier New" size="2" color="#f0f0g88f">Harga Rp. 17rb</font><br>
  
  
  <br><input type="submit" class="btn btn-success" name="submit3" value="Paket Inet 10GB 30Hari" style="width: 100%;height:40px;"/>
    <center><font face="Courier New" size="2" color="#f0f0g88f">Harga Rp. 22rb</font><br>
  
  <br><input type="submit" class="btn btn-success" name="submit4" value="Paket EDU 30Hari" style="width: 100%;height:40px;"/>
  <center><font face="Courier New" size="2" color="#f0f0g88f">Harga Rp. 27rb</font><br>
  
  <br><input type="submit" class="btn btn-success" name="submit5" value="Paket TLP Indosat" style="width: 100%;height:40px;" />
  <center><font face="Courier New" size="3" color="#f0f0g88f">Harga Rp. 7rb</font><br>
  
</table>



</form>
    

    <br><hr><center>
    <a href="transaksi.php">Transaksi</a> • <a href="logout.php">Logout</a> • <a href="about.php">About</a>
    <br>
    <br>
</div>  
</div>
</body>
</html>