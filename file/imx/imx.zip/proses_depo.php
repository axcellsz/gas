<?php
include 'koneksi.php';
session_start();

if (!isset($_SESSION['login'])){
    header("location:login.php");
    exit;
}
$username = $_SESSION['username'];
$req_depo = $_POST['depo'];

$sql="insert into deposit (username,req_depo) values
		('$username','$req_depo')";

  $hasil=mysqli_query($con,$sql);

  if ($hasil) {
	echo "<script>
		alert('Permintaan deposit berhasil, silahkan lanjut melakukan pembayaran');
		window.location = 'billing.php';
		</script>";
  }
else {
	echo "<script>
		alert('Permintaan deposit gagal, silahkan coba beberapa saat lagi');
		window.location = 'billing.php';
		</script>";
}







?>